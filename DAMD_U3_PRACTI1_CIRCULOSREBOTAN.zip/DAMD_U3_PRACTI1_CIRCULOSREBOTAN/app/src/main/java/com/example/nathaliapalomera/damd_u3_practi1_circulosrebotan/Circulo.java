package com.example.nathaliapalomera.damd_u3_practi1_circulosrebotan;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.CountDownTimer;

public class Circulo {

    float x,y;
    int despalzamiento;
    CountDownTimer timer;
    int color;

    public Circulo (int posx, int posy, final lienso l,int c)
    {
        y = posy;
        x = posx;
        color = c;

        timer = new CountDownTimer(1000,100) {
            @Override
            public void onTick(long millisUntilFinished) {
                x+= despalzamiento;
                if (x>=l.getWidth()-100)
                {
                   despalzamiento *=-1;
                }
                if (x<=0)
                {
                    despalzamiento *=-1;
                }

                y+=despalzamiento;
                if (y>=l.getHeight()-150)
                {
                   despalzamiento *=-1;
                }

                if (y<=0)
                {
                    despalzamiento *=-1;
                }
                l.invalidate();
            }

            @Override
            public void onFinish() {
                start();
            }
        };


    }

    public  void pintar (Canvas c, Paint p)
    {
        p.setColor(color);
        c.drawCircle(x,y,100,p);

    }

    public void mover (int desplaza)
    {
        despalzamiento = desplaza;
        timer.start();

    }
}
