package com.example.nathaliapalomera.damd_u3_practi1_circulosrebotan;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class lienso extends View {

    Circulo c1,c2,c3,c4,c5;

    public lienso(Context context) {
        super(context);

        c1 = new Circulo(300,300,this,Color.MAGENTA);
        c2 = new Circulo(500,700,this,Color.YELLOW);
        c3 = new Circulo(600,1100,this,Color.GREEN);
        c4 = new Circulo(100,800,this,Color.BLACK);
        c5 = new Circulo(200,1000,this,Color.CYAN);

        c1.mover(10);
        c2.mover(6);
        c3.mover(7);
        c4.mover(15);
        c5.mover(9);


    }

    public void onDraw (Canvas c)
    {
        Paint p = new Paint();
        c.drawColor(Color.BLUE);
        c1.pintar(c,p);
        c2.pintar(c,p);
        c3.pintar(c,p);
        c4.pintar(c,p);
        c5.pintar(c,p);

    }

    public boolean onTouchEvent( ) {


        return true;
    }
}
